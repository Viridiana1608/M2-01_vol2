func menu() {
    var num1: Float = 0
    var num2: Float = 0
    
    print("Ingresa el número de la operación que deseas hacer")
    print("Operaciones:\n1.Suma\n2.Resta\n3.Division\n4.Multiplicacion\n5.Salir")
    if let operacionInput = readLine(), let operacion = Int(operacionInput) {
        if operacion != 5 {
            print("Ingresa el primer valor: ")
            num1 = Float(readLine()!)!
            
            print("Ingresa el segundo valor: ")
            num2 = Float(readLine()!)!
            
            operaciones(caracterIngresado: operacion, num1: num1, num2: num2)
            
        } else {
            print("Adios")
        }
    } else {
        print("Operación no válida")
    }
}

func operaciones(caracterIngresado: Int, num1: Float, num2: Float) {
    var resultado: Float = 0
    
    switch caracterIngresado {
    case 1:
        resultado = suma(num1: num1, num2: num2)
    case 2:
        resultado = resta(num1: num1, num2: num2)
    case 3:
        resultado = division(num1: num1, num2: num2)
    case 4:
        resultado = multiplicacion(num1: num1, num2: num2)
    default:
        print("El número ingresado es incorrecto")
    }
    
    if resultado.isFinite {
        print("El resultado es: \(resultado)")
    } else {
        print("No se puede realizar la operación")
    }
}

func suma(num1: Float, num2: Float) -> Float {
    return num1 + num2
}

func resta(num1: Float, num2: Float) -> Float {
    return num1 - num2
}

func multiplicacion(num1: Float, num2: Float) -> Float {
    return num1 * num2
}

func division(num1: Float, num2: Float) -> Float {
    if num2 == 0 {
        return Float.infinity
    } else {
        return num1 / num2
    }
}

menu()
